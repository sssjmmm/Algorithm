import cv2
import numpy as np
import os


class seam_carving:
    # 构造函数
    def __init__(self, in_file, out_file):
        # initialize parameter
        self.filename = in_file
        self.filename_out = out_file
        
        # read in image and store as np.float64 format
        self.in_image = cv2.imread(in_file).astype(np.float64)
        self.in_height, self.in_width = self.in_image.shape[: 2]
        # 直接把缩放后的图横向设置为原图的一半
        self.out_width = self.in_image.shape[1] // 2
        self.out_height = self.in_image.shape[0]

        # keep tracking resulting image
        self.out_image = np.copy(self.in_image)

        # kernel for forward energy map calculation
        self.kernel_x = np.array([[0., 0., 0.], [-1., 0., 1.], [0., 0., 0.]], dtype=np.float64)
        self.kernel_y_left = np.array([[0., 0., 0.], [0., 0., 1.], [0., -1., 0.]], dtype=np.float64)
        self.kernel_y_right = np.array([[0., 0., 0.], [1., 0., 0.], [0., -1., 0.]], dtype=np.float64)

        # starting program
        self.start()

    def start(self):
        print("缩放前的图片信息：" + str(self.in_image.shape))
        self.seams_carving()  # 主要的缩放函数 
        self.save_picture(self.filename_out)  # 保存图片到filename_out路径中
        print("缩放后的图片信息：" + str(self.out_image.shape))

    # 缩放函数
    def seams_carving(self):
        # calculate number of rows and columns needed to be inserted or removed
        delta_row, delta_col = int(self.out_height - self.in_height), int(self.out_width - self.in_width)
        
        # 判断是变大还是变小
        # remove column
        if delta_col < 0:
            self.seams_removal(delta_col * -1)
        # insert column
        # elif delta_col > 0:
        #     self.seams_insertion(delta_col)

        # 翻转变大or变小
        # remove row
        if delta_row < 0:
            self.out_image = self.rotate_image(self.out_image, 1)  # 先转他个90度
            self.seams_removal(delta_row * -1)
            self.out_image = self.rotate_image(self.out_image, 0)  # 转回来
        # # insert row
        # elif delta_row > 0:
        #     self.out_image = self.rotate_image(self.out_image, 1)
        #     self.seams_insertion(delta_row)
        #     self.out_image = self.rotate_image(self.out_image, 0)

    # 缩小num_pixel像素
    def seams_removal(self, num_pixel):
        for _ in range(num_pixel):
            # 计算能量图
            energy_map = self.calc_energy_map()
            # 动态规划方法记录dp数组
            dp, path = self.cumulative_map_forward(energy_map)
            # 逆向寻路：能量和最小
            seam_idx = self.find_seam(dp, path)
            # 把找到的路删除
            self.delete_seam(seam_idx)

    # 计算能量图
    def calc_energy_map(self):
        b, g, r = cv2.split(self.out_image)
        b_energy = np.absolute(cv2.Scharr(b, -1, 1, 0)) + np.absolute(cv2.Scharr(b, -1, 0, 1))
        g_energy = np.absolute(cv2.Scharr(g, -1, 1, 0)) + np.absolute(cv2.Scharr(g, -1, 0, 1))
        r_energy = np.absolute(cv2.Scharr(r, -1, 1, 0)) + np.absolute(cv2.Scharr(r, -1, 0, 1))
        return b_energy + g_energy + r_energy

    # 用动态规划方法记录dp数组和来的路径，输入为能量图，输出是dp数组和路径
    def cumulative_map_forward(self, energy_map):
        m, n = energy_map.shape
        dp = np.copy(energy_map)
        path = np.zeros((m, n))  # path数组用于记录路径，要删除的点是从哪来的，-1左上，0上，1右上
        # 从上到下
        for row in range(1, m):  # 共m轮，m个最小能量和选最小
            for col in range(n):
                if col == 0:  # 第一列没有左上
                    if energy_map[row - 1, col] < energy_map[row - 1, col + 1]:  # 正上小于右上，取正上
                        path[row, col] = 0
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col]
                    else:  # 右上小，取右上
                        path[row, col] = 1
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col + 1]
                elif col == n - 1:  # 最后一列没有右上
                    if energy_map[row - 1, col - 1] < energy_map[row - 1, col]:  # 左上小于正上，取左上
                        path[row, col] = -1
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col - 1]
                    else:  # 正上更小，取正上
                        path[row, col] = 0
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col]
                else:  # 其他的中间列
                    if energy_map[row - 1, col - 1] < min(energy_map[row - 1, col], energy_map[row - 1, col + 1]):  # 左上最小
                        path[row, col] = -1
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col - 1]
                    elif energy_map[row - 1, col] < energy_map[row - 1, col + 1]:  # 正上最小
                        path[row, col] = 0
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col]
                    else:  # 右上最小
                        path[row, col] = 1
                        dp[row, col] = energy_map[row, col] + energy_map[row - 1, col + 1]
        return dp, path

    # 通过回溯路径数组找seam位于每行的第几列
    def find_seam(self, dp, path):
        m, n = dp.shape
        seam_idx = np.zeros((m, ), dtype=np.uint32)
        # 终点最小值对应的索引
        seam_idx[-1] = np.argmin(dp[-1])
        # 逆向寻找最小的路径
        for i in range(m - 2, -1, -1):
            j = seam_idx[i + 1]
            seam_idx[i] = j + path[i, j]

        return seam_idx        
            
    # 删除seam上的像素，输入为seam位于每行的列号数组
    def delete_seam(self, seam_idx):
        m, n = self.out_image.shape[: 2]
        output = np.zeros((m, n - 1, 3))
        for row in range(m):
            col = seam_idx[row]
            output[row, :, 0] = np.delete(self.out_image[row, :, 0], [col])
            output[row, :, 1] = np.delete(self.out_image[row, :, 1], [col])
            output[row, :, 2] = np.delete(self.out_image[row, :, 2], [col])
        self.out_image = np.copy(output)

    # 旋转图片
    def rotate_image(self, image, ccw):
        m, n, ch = image.shape
        output = np.zeros((n, m, ch))
        if ccw:
            image_flip = np.fliplr(image)
            for c in range(ch):
                for row in range(m):
                    output[:, row, c] = image_flip[row, :, c]
        else:
            for c in range(ch):
                for row in range(m):
                    output[:, m - 1 - row, c] = image[row, :, c]
        return output

    # 保存文件
    def save_picture(self, filename):
        cv2.imwrite(filename, self.out_image)

if __name__ == '__main__':
    
    while (True):
        in_file = input("请输入项目目录下的图片名称（带后缀）：")
        if os.path.exists(in_file) is False:
            print("不存在此图片")
        else:
            break
    out_file = "pictrue_result.jpg"

    obj = seam_carving(in_file, out_file)