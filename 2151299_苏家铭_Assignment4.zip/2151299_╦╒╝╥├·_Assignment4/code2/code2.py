from math import exp


if __name__ == '__main__':
    t = 0.001  # 步长
    end_threshold = 1e-10  # 结束阈值𝜂
    n = 1000  # 迭代次数

    x1, x2 = 0, 0  # 定义初始点
    y = exp(x1 + 3 * x2 - 0.1) + exp(x1 - 3 * x2 - 0.1) + exp(-x1 - 0.1)  # 函数
    gradient_x1 = exp(x1 + 3 * x2 - 0.1) + exp(x1 - 3 * x2 - 0.1) - exp(-x1 - 0.1)  # x1的梯度
    gradient_x2 = 3 * exp(x1 + 3 * x2 - 0.1) - 3 * exp(x1 - 3 * x2 - 0.1)  # x2的梯度

    for i in range(n):
        x1 -= t * gradient_x1
        x2 -= t * gradient_x2

        y_new = exp(x1 + 3 * x2 - 0.1) + exp(x1 - 3 * x2 - 0.1) + exp(-x1 - 0.1)  # 更新y值
        gradient_x1 = exp(x1 + 3 * x2 - 0.1) + exp(x1 - 3 * x2 - 0.1) - exp(-x1 - 0.1)  # 更新x1的梯度值
        gradient_x2 = 3 * exp(x1 + 3 * x2 - 0.1) - 3 * exp(x1 - 3 * x2 - 0.1)  # 更新x2的梯度值
        if abs(y - y_new) < end_threshold:  # 迭代前后y的差值|y𝑘 − y𝑘+1| < 𝜂时得到最优解
            break
        y = y_new  # yk更新

    print("最小值:" + "f*= {:.10f}\n".format(y_new) + "对应点(x1*, x2*):({:.10f}, {:.10f})".format(x1, x2))